package Arangoconf

import (
	"context"

	"fmt"

	driver "github.com/arangodb/go-driver"
	arangoHttp "github.com/arangodb/go-driver/http"
)

type Book struct {
	Title string `json:title`
	Price int
}

var ctx = context.Background()

var data []Book
var response interface{}

var db driver.Database
var err error
var client driver.Client
var col driver.Collection

func Initdb() {
	if db == nil {

		conn, err := arangoHttp.NewConnection(arangoHttp.ConnectionConfig{
			Endpoints: []string{"http://127.0.0.1:8529"},
		})
		if err != nil {
			// Handle error
			panic(err)
		}
		client, err := driver.NewClient(driver.ClientConfig{
			Connection:     conn,
			Authentication: driver.BasicAuthentication("root", ""),
		})
		if err != nil {
			// Handle error
			panic(err)
		}

		db, err = client.Database(nil, "testdb")
		if err != nil {
			panic(err)
		}
		fmt.Println(db)

		// col, err := db.CreateCollection(ctx, "test2", nil)
		// if err != nil {
		// 	fmt.Println(err)
		// 	panic(err)
		// }

		// book := Book{
		// 	Title: "ArangoDB Cookbook",
		// 	Price: 257,
		// }

		// meta, err := col.CreateDocument(nil, book)

		// if err != nil {
		// 	panic(err)
		// }

		//fmt.Printf("Created document in collection '%s' in database '%s'\n", col.Name(), db.Name())
		//fmt.Println(meta)

	}
}

func Createdocument(insertact string) {

	Initdb()
	cur, err := db.Query(ctx, insertact, nil)
	if err != nil {
		panic(err)
	}
	fmt.Println(cur)
}

func Getalldocuments(selectall string) {

	//var cur []string
	Initdb()
	cur, err := db.Query(ctx, selectall, nil)
	if err != nil {
		panic(err)
	}
	// json.Unmarshal(cur, &data)
	// for _, doc := range data {
	// 	fmt.Println(doc)
	// }
	var v interface{}
	for {
		_, err := cur.ReadDocument(nil, &v)
		if driver.IsNoMoreDocuments(err) {
			break
		}
		if err != nil {
			data = append(data, v.(Book))
		}

	}
	// for _, doc := range data {
	// 	fmt.Println(doc)
	// }
	fmt.Println(v)

}

func SpecificRecord(specificrecord string) {
	Initdb()
	cur, err := db.Query(ctx, specificrecord, nil)
	if err != nil {
		panic(err)
	}
	fmt.Println(cur)

}

func Retspecific(retspecificrecord string) {
	Initdb()
	cur, err := db.Query(ctx, retspecificrecord, nil)
	if err != nil {
		panic(err)
	}
	//fmt.Println(cur)

	//var v interface{}
	var books []Book
	for {
		var book Book
		_, err := cur.ReadDocument(ctx, &book)
		if driver.IsNoMoreDocuments(err) {
			break
		}
		if err != nil {
			// fmt.Println(v)
			// str, ok := v.([]Book)
			// if ok {
			// 	fmt.Println(str)
			// } else {
			// 	fmt.Println("Data is not a string.")
			// }
			panic(err)
		}
		books = append(books, book)

	}
	// for _, d := range response {
	// 	fmt.Println(d)
	// }
	fmt.Println(books)

}
