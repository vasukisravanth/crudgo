package Contro

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	driver "github.com/arangodb/go-driver"
	"github.com/vasuisravanth/Arangoconf"
)

var ctx = context.Background()

var db driver.Database
var client driver.Client
var err error

type Book struct {
	Title string `json:"Btitle"`
	Price int    `json:"Bprice"`
}

const fetchallactivi = `
for doc IN test2
    return doc
	
`
const insertact = `
INSERT {
	Title :"devilisback",
	Price :300
} INTO test2 `

const specificrec = `
FOR u IN test2
  FILTER u.Title == "devilis"
  REMOVE u IN test2
`

const retspecific = `
For u IN test2
  FILTER u.Title == "devil"
  return u`

func TodoHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("List of activities")

	cursor, err := db.Query(ctx, fetchallactivi, nil)
	if err != nil {
		panic(err)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	outResponse, _ := json.Marshal(cursor)
	w.Write(outResponse)

	fmt.Println(cursor)

}

// col, err := db.CreateCollection(ctx, "test2", nil)
// if err != nil {
// 	fmt.Println(err)
// 	panic(err)
// }

// book := Book{
// 	Title: "ArangoDB Cookbook",
// 	Price: 257,
// }

// meta, err := col.CreateDocument(nil, book)

// if err != nil {
// 	panic(err)
// }

//fmt.Printf("Created document in collection '%s' in database '%s'\n", col.Name(), db.Name())
//fmt.Println(meta)

// col, err := db.CreateCollection(ctx, "test2", nil)
// if err != nil {
// 	fmt.Println(err)
// 	panic(err)
// }

// book := Book{
// 	Title: "ArangoDB Cookbook",
// 	Price: 257,
// }

// meta, err := col.CreateDocument(nil, book)

// if err != nil {
// 	panic(err)
// }

//fmt.Printf("Created document in collection '%s' in database '%s'\n", col.Name(), db.Name())
//fmt.Println(meta)
//return db

func CreateHandler() {

	Arangoconf.Initdb()

	fmt.Println("Creating")

	Arangoconf.Createdocument(insertact)

}

func GetHandler() {
	Arangoconf.Initdb()

	fmt.Println("Retrieving")
	Arangoconf.Getalldocuments(fetchallactivi)

}

func Delspec() {
	Arangoconf.Initdb()
	fmt.Println("Deleting")
	Arangoconf.SpecificRecord(specificrec)

}

func Retrievspecific() {
	Arangoconf.Initdb()
	fmt.Println("specific fetching")
	Arangoconf.Retspecific(retspecific)

}
